﻿namespace Firsttutorials.ViewModel
{
    public class insertviewfamilytableviewmodel
    {
    }
}
